<?php
// Konfigurasi basis data
$servername = "localhost";
$username = "root";
$password = "";
$database = "appotek";

// Membuat koneksi ke basis data
$conn = new mysqli($servername, $username, $password, $database);

//membuat koneksi ke dashboard
session_start(); // Mulai sesi
$_SESSION['username'] = $nama_pengguna; // Simpan informasi pengguna dalam sesi
header("Location: dashboard.php"); // Alihkan ke dashboard
exit();
?>


// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data dari formulir pendaftaran
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Menyisipkan data ke dalam tabel pengguna
    $sql = "INSERT INTO pengguna (nama, email, password) VALUES ('$nama', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Pendaftaran berhasil. Silakan masuk.";
    } else {
        echo "Kesalahan: " . $sql . "<br>" . $conn->error;
    }
}

// Menutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>sign up</title>
</head>
<body>
    <h2>sign up</h2>
    <form method="post" action="">
        <label for="nama">Nama:</label>
        <input type="text" name="nama" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>

        <label for="password">Kata Sandi:</label>
        <input type="password" name="password" required><br><br>

        <input type="submit" value="Daftar">
    </form>
</body>
</html>
